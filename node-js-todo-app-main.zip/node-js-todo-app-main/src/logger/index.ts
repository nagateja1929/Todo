import log from 'npmlog';

export const logger = log;
